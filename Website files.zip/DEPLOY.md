# Getting this live — free, ~10 minutes

You have three files: `index.html`, `styles.css`, `script.js`. They belong together in one folder — don't rename them, the HTML file links to the other two by name.

## Fastest path: Netlify (drag-and-drop, no account setup needed to preview)

1. Go to https://app.netlify.com/drop
2. Drag the whole `wellness-site` folder (all three files) into the browser window
3. Netlify gives you a live URL immediately (something like `random-name-123.netlify.app`)
4. To keep it and get a real domain: create a free Netlify account, claim the site, then under **Site settings → Domain management** you can connect a custom domain you buy elsewhere (Namecheap, Google Domains, etc. — roughly $12–15/year)

## Alternative: GitHub Pages (if you'll be editing this over time)

1. Create a free GitHub account and a new repository
2. Upload the three files to it
3. Go to **Settings → Pages**, set source to the main branch, save
4. Your site is live at `yourusername.github.io/repo-name` within a few minutes
5. This route is better if you want version history as you keep adding frameworks/challenges over time

## What's already wired up

- Nav, buttons, and section anchors all work out of the box
- The email signup form is front-end only right now — it shows a confirmation message but doesn't actually collect emails yet. When you're ready, the easiest no-code option is swapping the form for a **Mailchimp** or **ConvertKit** embed form (both have free tiers) — say the word and I'll wire that in
- "Our products," Instagram, and TikTok links in the footer are placeholders (`#`) — send me the real URLs and I'll drop them in

## What to send me next

- Real links for the shop/social footer items
- Whether you want the framework/challenge/resource "Read more" pages built out next, or want to review this structure first
